0x05-pointers_arrays_strings my first readme
