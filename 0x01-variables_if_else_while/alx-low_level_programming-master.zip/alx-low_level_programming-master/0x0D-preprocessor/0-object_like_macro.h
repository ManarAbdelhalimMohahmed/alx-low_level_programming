#ifndef OBJECT_LIKE_MACRO_H
#define OBJECT_LIKE_MACRO_H
#define SIZE 1024
#endif
