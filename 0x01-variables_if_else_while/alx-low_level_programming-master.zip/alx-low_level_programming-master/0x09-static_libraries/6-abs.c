#include "main.h"

/**
 * _abs- function to give absoulute of number
 *
 * @n: check input of function
 *
 * Return: return n
*/

int _abs(int n)
{
	if (n < 0)
		n = (-1) * n;
	return (n);

}
