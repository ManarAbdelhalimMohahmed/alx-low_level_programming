#include <stdio.h> 
 /** 
  * main - start point of the program 
  * 
  * Return: always must be 0 in case you are using int if you using void 
  * 
  *  no need to return keyword 
  */ 
 int main(void) 
 { 
 /* initialize a counter that hold the value of char as 1=a ,2=b and so on*/ 
 int n; 
 for (n = 'a'; n <= 'z'; n++) 
 { 
 /* ignor both of e and q by using contiue keyword */ 
 /* performing next struction*/ 
 if (n != 'e' && n != 'q') 
 { 
 putchar(n); 
 continue; 
 } 
 } 
 putchar ('\n'); 
         return (0); 
 }
