#include <stdio.h>

/**
 * main - prints "Programming is like building a multilingual puzzle,
 * followed by a newline."
 * return 0.
 * /

int main(void) 

{
        puts("\"programming is like building a multilingual puzzle");
	return(0);	
	}	
