0x03-debugging my first readme
