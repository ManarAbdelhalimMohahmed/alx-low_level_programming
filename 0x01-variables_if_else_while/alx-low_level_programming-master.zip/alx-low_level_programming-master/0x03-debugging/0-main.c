#include "main.h"

/**
* main - A function that should work I hope
* Return: 0
*/

int main(void)

{
	int i;

	i = 0;
	positive_or_negative(i);
	return (0);
}
