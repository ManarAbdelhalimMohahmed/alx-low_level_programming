#include "main.h"
/**
* main - check the code
*
* Return: Always 0.
*/
int main(void)
{
print_most_numbers();
return (0);
}
